<?php

namespace Modules\PayHereModule;

use App\Contracts\PaymentGatewayInterface;
use App\Models\Setting;

class PayHerePaymentGateway implements PaymentGatewayInterface
{
    public function getName(): string
    {
        return 'payhere';
    }

    public function isEnabled(): bool
    {
        $enabled = filter_var(Setting::get('payment_payhere_enabled', '0'), FILTER_VALIDATE_BOOLEAN);
        $merchantId = $this->getMerchantId();

        return $enabled && ! empty($merchantId);
    }

    public function getMerchantId(): string
    {
        return (string) (Setting::get('payment_payhere_merchant_id') ?: '');
    }

    public function getMerchantSecret(): string
    {
        return (string) (Setting::get('payment_payhere_merchant_secret') ?: '');
    }

    public function isSandbox(): bool
    {
        return filter_var(Setting::get('payment_payhere_sandbox', '1'), FILTER_VALIDATE_BOOLEAN);
    }

    public function getPayUrl(): string
    {
        return $this->isSandbox()
            ? 'https://sandbox.payhere.lk/pay'
            : 'https://www.payhere.lk/pay';
    }

    /**
     * Generate PayHere hash for security.
     * Hash = MD5(merchant_id + order_id + amount + currency + merchant_secret)
     */
    public function generateHash(string $orderId, string $amount, string $currency = 'LKR'): string
    {
        $secret = $this->getMerchantSecret();
        $concat = $this->getMerchantId() . $orderId . $amount . $currency . $secret;

        return strtoupper(md5($concat));
    }

    /**
     * Verify PayHere notify hash.
     */
    public function verifyNotifyHash(array $params): bool
    {
        $receivedHash = $params['md5sig'] ?? '';
        $orderId = $params['order_id'] ?? '';
        $amount = $params['payhere_amount'] ?? '';
        $currency = $params['payhere_currency'] ?? 'LKR';

        $expectedHash = $this->generateHash($orderId, $amount, $currency);

        return hash_equals($expectedHash, $receivedHash);
    }

    /**
     * PayHere uses redirect flow - stub for interface compatibility.
     */
    public function createPaymentIntent(int $amountInCents, string $currency = 'usd', array $metadata = []): array
    {
        return [
            'success' => true,
            'redirect' => true,
            'gateway' => 'payhere',
        ];
    }

    /**
     * PayHere confirmation happens via notify callback - stub for interface.
     */
    public function confirmPayment(string $paymentIntentId, ?string $paymentMethodId = null): array
    {
        return [
            'success' => false,
            'error' => 'PayHere uses redirect flow. Payment is confirmed via callback.',
        ];
    }

    /**
     * Stub for interface compatibility.
     */
    public function getPaymentIntent(string $paymentIntentId): array
    {
        return [
            'success' => false,
            'error' => 'Not applicable for PayHere',
        ];
    }
}
