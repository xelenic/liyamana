@extends('layouts.admin')

@section('title', 'Gemini Image Settings')
@section('page-title', 'Gemini Image Settings')

@section('content')
<div class="my-4">
    <div class="mb-4">
        <a href="{{ route('admin.settings', ['tab' => 'general']) }}" class="text-decoration-none">
            <i class="fas fa-arrow-left me-1"></i>Back to Settings
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <h5 class="card-title mb-4"><i class="fas fa-cog me-2"></i>Gemini Image Settings</h5>
            <form action="{{ route('admin.nanobanana.settings.update') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label class="form-label">Gemini API Key</label>
                    <input type="password" name="gemini_api_key" class="form-control" value="{{ $gemini_api_key }}" placeholder="Your Gemini API key" autocomplete="off">
                    <small class="text-muted">Get your API key from <a href="https://aistudio.google.com/apikey" target="_blank">Google AI Studio</a>.</small>
                </div>
                <div class="mb-3">
                    <label class="form-label">Model</label>
                    <select name="gemini_image_model" class="form-select">
                        <option value="gemini-3-pro-image-preview" {{ ($gemini_image_model ?? 'gemini-3-pro-image-preview') === 'gemini-3-pro-image-preview' ? 'selected' : '' }}>Gemini 3 Pro Image</option>
                        <option value="gemini-2.5-flash-image" {{ ($gemini_image_model ?? '') === 'gemini-2.5-flash-image' ? 'selected' : '' }}>Gemini 2.5 Flash Image (fast)</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Aspect Ratio</label>
                    <select name="nanobanana_image_size" class="form-select">
                        <option value="1:1" {{ ($nanobanana_image_size ?? '') === '1:1' ? 'selected' : '' }}>1:1 (Square)</option>
                        <option value="16:9" {{ ($nanobanana_image_size ?? '') === '16:9' ? 'selected' : '' }}>16:9</option>
                        <option value="9:16" {{ ($nanobanana_image_size ?? '') === '9:16' ? 'selected' : '' }}>9:16</option>
                        <option value="4:3" {{ ($nanobanana_image_size ?? '') === '4:3' ? 'selected' : '' }}>4:3</option>
                        <option value="3:4" {{ ($nanobanana_image_size ?? '') === '3:4' ? 'selected' : '' }}>3:4</option>
                        <option value="2:3" {{ ($nanobanana_image_size ?? '') === '2:3' ? 'selected' : '' }}>2:3</option>
                        <option value="3:2" {{ ($nanobanana_image_size ?? '') === '3:2' ? 'selected' : '' }}>3:2</option>
                        <option value="21:9" {{ ($nanobanana_image_size ?? '') === '21:9' ? 'selected' : '' }}>21:9 (Ultra-wide)</option>
                        <option value="auto" {{ ($nanobanana_image_size ?? '') === 'auto' ? 'selected' : '' }}>Auto</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Cost per Image (Credits)</label>
                    <input type="number" name="gemini_image_cost" class="form-control" value="{{ $gemini_image_cost ?? 1 }}" min="0" step="0.01" placeholder="1">
                    <small class="text-muted">Credits deducted from user's top-up balance per image generated</small>
                </div>
                <div class="mb-3">
                    <label class="form-label">Resolution (Gemini 3 Pro only)</label>
                    <select name="nanobanana_resolution" class="form-select">
                        <option value="1K" {{ ($nanobanana_resolution ?? '2K') === '1K' ? 'selected' : '' }}>1K</option>
                        <option value="2K" {{ ($nanobanana_resolution ?? '2K') === '2K' ? 'selected' : '' }}>2K</option>
                        <option value="4K" {{ ($nanobanana_resolution ?? '2K') === '4K' ? 'selected' : '' }}>4K</option>
                    </select>
                    <small class="text-muted">For Gemini 3 Pro Image model; 2.5 Flash uses default</small>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i>Save Settings
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
