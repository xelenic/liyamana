<div class="mb-3">
    <label class="form-label">Name</label>
    <input type="text" name="name" class="form-control" value="{{ old('name', $template->name ?? '') }}" required>
</div>
<div class="mb-3">
    <label class="form-label">Prompt</label>
    <textarea name="prompt" class="form-control" rows="4" required>{{ old('prompt', $template->prompt ?? '') }}</textarea>
    <small class="text-muted">Use {{fieldName}} for placeholder substitution</small>
</div>
<div class="mb-3">
    <label class="form-label">Description</label>
    <textarea name="description" class="form-control" rows="2">{{ old('description', $template->description ?? '') }}</textarea>
</div>
<div class="mb-3">
    <label class="form-label">Defined Fields (JSON)</label>
    <textarea name="defined_fields" class="form-control font-monospace" rows="6">{{ old('defined_fields', json_encode($template->defined_fields ?? [['name'=>'subject','label'=>'Subject','type'=>'text','required'=>true]], JSON_PRETTY_PRINT)) }}</textarea>
    <small class="text-muted">Array of {name, label, type, required, options}</small>
</div>
<div class="mb-3">
    <label class="form-label">Thumbnail Image</label>
    <input type="file" name="image" class="form-control" accept="image/*">
    @if(isset($template) && $template->thumbnail_url)
        <div class="mt-2"><img src="{{ $template->thumbnail_url }}" alt="" style="max-height: 80px; border-radius: 6px;"></div>
    @endif
</div>
<div class="mb-3">
    <div class="form-check form-switch">
        <input type="hidden" name="upload_image" value="0">
        <input type="checkbox" name="upload_image" value="1" class="form-check-input" {{ old('upload_image', $template->upload_image ?? false) ? 'checked' : '' }}>
        <label class="form-check-label">Require user to upload an image</label>
    </div>
</div>
<div class="mb-3">
    <div class="form-check form-switch">
        <input type="hidden" name="is_active" value="0">
        <input type="checkbox" name="is_active" value="1" class="form-check-input" {{ old('is_active', $template->is_active ?? true) ? 'checked' : '' }}>
        <label class="form-check-label">Active</label>
    </div>
</div>
<div class="mb-3">
    <label class="form-label">Sort Order</label>
    <input type="number" name="sort_order" class="form-control" value="{{ old('sort_order', $template->sort_order ?? 0) }}" min="0">
</div>
