@extends('layouts.app')

@section('title', 'Create with ' . $template->name)

@push('styles')
<style>
    .nb-form-card { max-width: 560px; margin: 0 auto; }
    .nb-preview { aspect-ratio: 1; background: #f8fafc; border-radius: 8px; display: flex; align-items: center; justify-content: center; }
    .nb-preview img { max-width: 100%; max-height: 100%; object-fit: contain; }
</style>
@endpush

@section('content')
<div class="container py-4">
    <div class="mb-4">
        <a href="{{ route('design.templates.explore') }}" class="text-decoration-none">
            <i class="fas fa-arrow-left me-1"></i>Back to Explore
        </a>
    </div>

    <div class="card border-0 shadow-sm nb-form-card">
        <div class="card-body p-4">
            <h4 class="mb-2">{{ $template->name }}</h4>
            @if($template->description)
                <p class="text-muted small mb-4">{{ $template->description }}</p>
            @endif

            <div class="row mb-4">
                <div class="col-md-5">
                    <div class="nb-preview">
                        @if($template->thumbnail_url)
                            <img src="{{ $template->thumbnail_url }}" alt="{{ $template->name }}">
                        @else
                            <i class="fas fa-image fa-3x text-secondary"></i>
                        @endif
                    </div>
                </div>
                <div class="col-md-7">
                    <form id="nbGenerateForm">
                        @csrf
                        <input type="hidden" name="template_id" value="{{ $template->id }}">

                        @foreach($template->defined_fields ?? [] as $field)
                            <div class="mb-3">
                                <label class="form-label">{{ $field['label'] ?? $field['name'] }}{{ ($field['required'] ?? false) ? ' *' : '' }}</label>
                                @if(($field['type'] ?? 'text') === 'textarea')
                                    <textarea name="fields[{{ $field['name'] }}]" class="form-control" rows="2" {{ ($field['required'] ?? false) ? 'required' : '' }}></textarea>
                                @elseif(($field['type'] ?? 'text') === 'select')
                                    <select name="fields[{{ $field['name'] }}]" class="form-select" {{ ($field['required'] ?? false) ? 'required' : '' }}>
                                        <option value="">-- Select --</option>
                                        @foreach($field['options'] ?? [] as $opt)
                                            <option value="{{ $opt }}">{{ $opt }}</option>
                                        @endforeach
                                    </select>
                                @else
                                    <input type="text" name="fields[{{ $field['name'] }}]" class="form-control" value="{{ $field['options'][0] ?? '' }}" {{ ($field['required'] ?? false) ? 'required' : '' }}>
                                @endif
                            </div>
                        @endforeach

                        @if($template->upload_image)
                            <div class="mb-3">
                                <label class="form-label">Upload Image *</label>
                                <input type="file" name="image" class="form-control" accept="image/*" required>
                                <small class="text-muted">Required for this template</small>
                            </div>
                        @endif

                        <div id="nbError" class="alert alert-danger d-none" role="alert"></div>
                        <div id="nbProgress" class="d-none mb-3">
                            <div class="progress">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%"></div>
                            </div>
                            <p class="small text-muted mb-0">Generating your image...</p>
                        </div>

                        @if($cost > 0)
                        <p class="small text-muted mb-2">
                            <i class="fas fa-coins me-1"></i>Cost: {{ format_price($cost) }} per image
                            <span class="ms-2">Balance: {{ format_price($balance) }}</span>
                        </p>
                        @endif

                        <button type="submit" class="btn btn-primary btn-lg w-100" id="nbSubmitBtn">
                            <i class="fas fa-magic me-2"></i>Generate
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('nbGenerateForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = document.getElementById('nbSubmitBtn');
    const errEl = document.getElementById('nbError');
    const progress = document.getElementById('nbProgress');

    btn.disabled = true;
    errEl.classList.add('d-none');
    progress.classList.remove('d-none');

    const formData = new FormData(this);

    try {
        const r = await fetch('{{ route("design.nanobanana.generate") }}', {
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' },
            body: formData
        });
        const data = await r.json();
        if (!data.success) {
            throw new Error(data.message || 'Generation failed');
        }
        const imgUrl = data.image_url;
        if (imgUrl) {
            window.location.href = '{{ route("design.create") }}?multi=true&generated_image=' + encodeURIComponent(imgUrl);
            return;
        }
        throw new Error('No image returned');
    } catch (e) {
        errEl.classList.remove('d-none');
        errEl.textContent = e.message || 'Something went wrong';
    } finally {
        btn.disabled = false;
        progress.classList.add('d-none');
    }
});
</script>
@endsection
